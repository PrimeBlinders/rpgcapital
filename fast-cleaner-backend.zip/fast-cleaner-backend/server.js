const mysql = require('mysql2');
const express = require('express');
const app = express();
// New
const cors = require('cors');
const multer = require('multer');
const axios = require('axios');
const pdfParse = require('pdf-parse');
const bodyParser = require('body-parser');
require('dotenv').config();
const Anthropic = require('@anthropic-ai/sdk');

app.use(bodyParser.json());
app.use(express.json());
// Enable CORS for all origins or specify the allowed origin
app.use(cors({
  origin: 'http://localhost:3000', // Allow requests from your frontend
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// Set up multer for file upload
const upload = multer({ storage: multer.memoryStorage() });

// POST route to handle PDF upload, text extraction, and summarization
app.post('/api/upload-pdf', upload.single('file'), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }

    try {
        // Step 1: Extract text from the PDF
        const pdfText = await pdfParse(req.file.buffer);
        console.log('Extracted Text:', pdfText.text);

        // Step 2: Summarize the extracted text using Anthropic API
        const summary = await summarizeWithAnthropic(pdfText.text);
        console.log('Summarize Text:', summary);

        // Step 3: Send back the summary to the client
        res.json({ summary });
    } catch (error) {
        console.error('Error processing PDF:', error.response?.data || error.message);
        res.status(500).json({ error: 'Failed to process the PDF' });
    }
});

const summarizeWithAnthropic = async (text) => {
  const anthropic = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY, // Use your environment variable for the API key
  });

  try {
  const msg = await anthropic.messages.create({
    model: "claude-3-5-opus",//claude-3-5-sonnet-20241022", // Change the model name if needed
    max_tokens: 8192, // Adjust the max tokens according to your preference
    messages: [{
      role: "user",
      content: `Summarize all the relevant table of contents (like Roof, Bathroom, Floor)  with critical points for house inspection repairing in order of their priority (Do not include any other unnecessary text):\n\n${text}`,
    }],
  });

  console.log('Message > ' + JSON.stringify(msg.content));
     return msg.content[0].text; // Return the summarized text

} catch (error) {
  console.error('Error during summarization:', error.message || error);
  throw error; // Rethrow the error so the caller can handle it
}
}

app.post('/api/generate-solution', async (req, res) => {
  const { text } = req.body;
  if (!text) {
      return res.status(400).json({ error: 'No text provided' });
  }

  try {
      // Here you can call the function to generate a solution based on the provided text
      console.log('Solution Text >> ' + text);

      const solution = await generateSolution(text);
      //console.log('Solution Server >> ' + solution);
      res.json({ solution });
  } catch (error) {
      console.error('Error generating solution:', error.message);
      res.status(500).json({ error: 'Failed to generate solution' });
  }
});

const generateSolution = async (text) => {
  const anthropic = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY_SOLUTION, // Use your environment variable for the API key
  });

  try {
  const msg = await anthropic.messages.create({
    model: "claude-3-5-opus",//claude-3-5-sonnet-20241022", // Change the model name if needed
    max_tokens: 8192, // Adjust the max tokens according to your preference
    messages: [{
      role: "user",
      content: `Provide a practical solution for the following issue in 3-4 lines:\n\n${text}`,
    }],
  });

  // if (msg && msg.completion) {
  console.log('Solution Final > ' + JSON.stringify(msg.content));
     return msg.content[0].text; // Return the summarized text
  // } else {
  //   throw new Error('Summarization failed');
  // }
} catch (error) {
  console.error('Error during summarization:', error.message || error);
  throw error; // Rethrow the error so the caller can handle it
}
}

// const db = mysql.createConnection({
//     host: process.env.DB_HOST,
//     user: process.env.DB_USERNAME,
//     password: process.env.DB_PASS,
//     database: process.env.DB_NAME,
// });

// db.connect((err) => {
//     if (err) {
//         console.error('Database connection failed:', err);
//         return;
//     }
//     console.log('Connected to MySQL database');
// });

app.listen(3002, () => {
  console.log('Server is running on port 3002');
});
